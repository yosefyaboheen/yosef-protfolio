package datebase.restaurant.hospital;

public class DoctorUnavailableException extends Exception {

    public DoctorUnavailableException(String message) {
        super(message);
    }
}