package datebase.restaurant.hospital;

public abstract class Employee extends Person {
    private double salary;
    private int workingHours;

    public Employee(String name, String nationalId, String phone,double salary,int workingHours) {
        super(name, nationalId, phone);
        this.salary=salary;
        this.workingHours=workingHours;
    }


    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(int workingHours) {
        this.workingHours = workingHours;
    }
}
