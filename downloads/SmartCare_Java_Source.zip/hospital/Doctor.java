package datebase.restaurant.hospital;

public class Doctor extends Employee {
    private String specialization;
    private double fee;

    public Doctor(String name, String nationalId, String phone, double salary, int workingHours, String specialization, double fee) {
        super(name, nationalId, phone, salary, workingHours);
        this.specialization = specialization;
        this.fee = fee;
    }

    public Doctor(String name, String nationalId, String phone, String specialization) {

        this(name, nationalId, phone, 0.0, 0, specialization, 0.0);
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    @Override
    public void displayInfo() {
        System.out.println("نوع الشخص: طبيب");
        System.out.println("Name: " + getName());
        System.out.println("Doctor ID: " + getId());
        System.out.println("National ID: " + getNationalId());
        System.out.println("Phone: " + getPhone());
        System.out.println("Salary: " + getSalary());
        System.out.println("Working Hours: " + getWorkingHours());
        System.out.println("Specialization: " + specialization);
        System.out.println("Fee: " + fee);
    }
}

