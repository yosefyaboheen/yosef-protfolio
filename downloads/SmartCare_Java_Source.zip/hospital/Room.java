package datebase.restaurant.hospital;

public class Room {

    private int roomNumber;
    private boolean available;

    public Room(int roomNumber, boolean available) {
        this.roomNumber = roomNumber;
        this.available = available;
    }

    public Room(int roomNumber) {
        this(roomNumber, true);
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public void displayInfo() {

        System.out.println("Room Number: " + roomNumber);
        System.out.println("Available: " + available);
    }

}
