package datebase.restaurant.hospital;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main extends Application {

    private Button btn_addPatient, btn_bookAppointment, btn_updateStatus, btn_showAll, btn_export;
    private Label lbl_title, lbl_pName, lbl_pId, lbl_pPhone, lbl_pBlood, lbl_pDiagnosis,
            lbl_docSelect, lbl_patSelect, lbl_date, lbl_time, lbl_appSelect, lbl_statusSelect;
    private TextField tf_pName, tf_pId, tf_pPhone, tf_pBlood, tf_pDiagnosis, tf_date, tf_time;
    private ComboBox<String> cb_doctors, cb_patients, cb_appointments, cb_statuses;
    private TextArea ta_history;
    private final ArrayList<Doctor> doctors = new ArrayList<>();
    private final ArrayList<Nurse> nurses = new ArrayList<>();
    private final ArrayList<Patient> patients = new ArrayList<>();
    private final ArrayList<Person> people = new ArrayList<>();
    private final ArrayList<Appointment> appointments = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        loadDoctorsFromFile();
        createNurses();
        initialize();
        for (Doctor doctor : doctors) {
            cb_doctors.getItems().add(
                    doctor.getName() + " - " + doctor.getSpecialization()
            );
        }

        HBox patientRow1 = new HBox(10, lbl_pName, tf_pName, lbl_pId, tf_pId, lbl_pPhone, tf_pPhone);
        patientRow1.setAlignment(Pos.CENTER);

        HBox patientRow2 = new HBox(10, lbl_pBlood, tf_pBlood, lbl_pDiagnosis, tf_pDiagnosis, btn_addPatient);
        patientRow2.setAlignment(Pos.CENTER);

        VBox patientSection = new VBox(10, new Separator(), patientRow1, patientRow2);

        HBox appointmentRow1 = new HBox(10, lbl_docSelect, cb_doctors, lbl_patSelect, cb_patients);
        appointmentRow1.setAlignment(Pos.CENTER);

        HBox appointmentRow2 = new HBox(10, lbl_date, tf_date, lbl_time, tf_time, btn_bookAppointment);
        appointmentRow2.setAlignment(Pos.CENTER);

        VBox appointmentSection = new VBox(10, new Separator(), appointmentRow1, appointmentRow2);

        HBox statusRow = new HBox(10, lbl_appSelect, cb_appointments, lbl_statusSelect, cb_statuses, btn_updateStatus);
        statusRow.setAlignment(Pos.CENTER);

        VBox statusSection = new VBox(10, new Separator(), statusRow);

        HBox bottomButtons = new HBox(20, btn_showAll, btn_export);
        bottomButtons.setAlignment(Pos.CENTER);

        VBox rootPane = new VBox(15, lbl_title, patientSection, appointmentSection, statusSection, new Separator(), bottomButtons, ta_history);

        rootPane.setMinSize(850, 700);
        rootPane.setAlignment(Pos.CENTER);
        rootPane.setPadding(new Insets(15));

        configureEvents();
        configureStyles();

        Scene scene = new Scene(rootPane);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart Care Hospital Management System");
        primaryStage.show();
    }

    private void configureEvents() {

        btn_addPatient.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                addPatient();
            }
        });

        btn_bookAppointment.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                bookAppointment();
            }
        });

        btn_updateStatus.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                updateAppointmentStatus();
            }
        });

        btn_showAll.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                showAllPeople();
            }
        });

        btn_export.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                saveAppointmentsToFile();
            }
        });
    }

    private void addPatient() {
        String name = tf_pName.getText().trim();
        String nationalId = tf_pId.getText().trim();
        String phone = tf_pPhone.getText().trim();
        String bloodType = tf_pBlood.getText().trim();
        String diagnosis = tf_pDiagnosis.getText().trim();

        if (name.isEmpty() || nationalId.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "خطأ إدخال", "يرجى تعبئة اسم المريض ورقم الهوية.");
            return;
        }

        Patient patient = new Patient(name, nationalId, phone, bloodType, diagnosis);

        patients.add(patient);
        people.add(patient);
        cb_patients.getItems().add(patient.getName());

        ta_history.appendText("[النظام] تم تسجيل المريض (" + name + ") بنجاح.\n");

        clearPatientFields();
    }

    private void bookAppointment() {
        int doctorIndex = cb_doctors.getSelectionModel().getSelectedIndex();
        int patientIndex = cb_patients.getSelectionModel().getSelectedIndex();

        String date = tf_date.getText().trim();
        String time = tf_time.getText().trim();

        if (doctorIndex == -1 || patientIndex == -1 || date.isEmpty() || time.isEmpty()) {

            showAlert(Alert.AlertType.ERROR, "خطأ", "تأكد من اختيار الطبيب والمريض وتحديد التاريخ والوقت.");
            return;
        }

        Doctor selectedDoctor = doctors.get(doctorIndex);
        Patient selectedPatient = patients.get(patientIndex);

        try {
            validateDoctorAvailability(selectedDoctor, date, time);

            Appointment newAppointment = new Appointment(selectedDoctor, selectedPatient, date, time, "مجدول");

            appointments.add(newAppointment);

            cb_appointments.getItems().add("موعد " + appointments.size() + " - د. " + selectedDoctor.getName() + " - " + selectedPatient.getName());

            ta_history.appendText("[موعد] تم حجز موعد للمريض (" + selectedPatient.getName() + ") مع د. (" + selectedDoctor.getName() + ") بتاريخ " + date + " الساعة " + time + ".\n");

            tf_date.clear();
            tf_time.clear();

        } catch (DoctorUnavailableException exception) {
            showAlert(Alert.AlertType.ERROR, "تعارض المواعيد", exception.getMessage());
        }
    }

    private void validateDoctorAvailability(Doctor selectedDoctor, String date, String time
    ) throws DoctorUnavailableException {

        for (Appointment appointment : appointments) {
            boolean sameDoctor =
                    appointment.getDoctor().getId() == selectedDoctor.getId();

            boolean sameDate =
                    appointment.getDate().equalsIgnoreCase(date);

            boolean sameTime =
                    appointment.getTime().equalsIgnoreCase(time);

            boolean appointmentStillActive =
                    !appointment.getStatus().equalsIgnoreCase("مكتمل");

            if (sameDoctor && sameDate && sameTime && appointmentStillActive) {

                throw new DoctorUnavailableException(
                        "تعذر الحجز: الطبيب مرتبط بموعد آخر في التاريخ والوقت نفسيهما."
                );
            }
        }
    }

    private void updateAppointmentStatus() {
        int appointmentIndex = cb_appointments.getSelectionModel().getSelectedIndex();

        String newStatus = cb_statuses.getSelectionModel().getSelectedItem();

        if (appointmentIndex == -1 || newStatus == null) {
            showAlert(Alert.AlertType.ERROR, "خطأ", "يرجى تحديد الموعد والحالة الجديدة.");
            return;
        }

        Appointment selectedAppointment = appointments.get(appointmentIndex);

        selectedAppointment.setStatus(newStatus);

        ta_history.appendText("[تحديث] الموعد رقم " + (appointmentIndex + 1) + " أصبحت حالته: " + newStatus + ".\n");
    }

    private void showAllPeople() {
        ta_history.clear();
        ta_history.appendText("========== قائمة الأشخاص - Polymorphism ==========\n");

        for (Person person : people) {
            person.displayInfo();

            ta_history.appendText("النوع: " + person.getClass().getSimpleName() + " | المعرف: " + person.getId() + " | الاسم: " + person.getName() + "\n");
        }
    }

    private void initialize() {
        lbl_title = new Label("نظام إدارة المستشفى الذكي - Smart Care");

        lbl_pName = new Label("الاسم:");
        lbl_pId = new Label("الهوية:");
        lbl_pPhone = new Label("الهاتف:");
        lbl_pBlood = new Label("فصيلة الدم:");
        lbl_pDiagnosis = new Label("التشخيص:");

        lbl_docSelect = new Label("الطبيب:");
        lbl_patSelect = new Label("المريض:");
        lbl_date = new Label("التاريخ:");
        lbl_time = new Label("الوقت:");

        lbl_appSelect = new Label("الموعد:");
        lbl_statusSelect = new Label("الحالة:");

        tf_pName = new TextField();
        tf_pId = new TextField();
        tf_pPhone = new TextField();
        tf_pBlood = new TextField();
        tf_pDiagnosis = new TextField();
        tf_date = new TextField();
        tf_time = new TextField();

        tf_date.setPromptText("مثال: 2026-07-18");
        tf_time.setPromptText("مثال: 10:30");

        cb_doctors = new ComboBox<>();
        cb_patients = new ComboBox<>();
        cb_appointments = new ComboBox<>();
        cb_statuses = new ComboBox<>();

        cb_statuses.getItems().addAll("مجدول", "قيد التنفيذ", "مكتمل");

        btn_addPatient = new Button("تسجيل المريض");
        btn_bookAppointment = new Button("حجز الموعد");
        btn_updateStatus = new Button("تحديث الحالة");
        btn_showAll = new Button("عرض الكل");
        btn_export = new Button("حفظ المواعيد");

        ta_history = new TextArea();
        ta_history.setEditable(false);
        ta_history.setWrapText(true);
        ta_history.setPrefRowCount(18);
        ta_history.appendText("--- مرحباً بك، تم تشغيل النظام ---\n");
    }

    private void configureStyles() {
        setFontSize(13,
                tf_pName,
                tf_pId,
                tf_pPhone,
                tf_pBlood,
                tf_pDiagnosis,
                tf_date,
                tf_time,
                cb_doctors,
                cb_patients,
                cb_appointments,
                cb_statuses,
                ta_history,
                btn_addPatient,
                btn_bookAppointment,
                btn_updateStatus,
                btn_showAll,
                btn_export
        );

        setFontSize(
                13,
                lbl_pName,
                lbl_pId,
                lbl_pPhone,
                lbl_pBlood,
                lbl_pDiagnosis,
                lbl_docSelect,
                lbl_patSelect,
                lbl_date,
                lbl_time,
                lbl_appSelect,
                lbl_statusSelect
        );

        lbl_title.setFont(new Font("Arial", 22));
        lbl_title.setStyle("-fx-font-weight: bold;" + "-fx-text-fill: #229E99;");

        btn_addPatient.setStyle("-fx-background-color: #229E99;" + "-fx-text-fill: white;");

        btn_bookAppointment.setStyle("-fx-background-color: #229E99;" + "-fx-text-fill: white;");

        btn_updateStatus.setStyle("-fx-background-color: #3C78D8;" + "-fx-text-fill: white;");

        btn_export.setStyle("-fx-background-color: #6AA84F;" + "-fx-text-fill: white;");
    }

    private void clearPatientFields() {
        tf_pName.clear();
        tf_pId.clear();
        tf_pPhone.clear();
        tf_pBlood.clear();
        tf_pDiagnosis.clear();
    }

    private void loadDoctorsFromFile() {
        File doctorFile = new File("src/datebase/restaurant/hospital/doctors.txt");

        if (!doctorFile.exists()) {
            showAlert(Alert.AlertType.WARNING, "تنبيه", "ملف doctors.txt غير موجود في المسار المحدد.");
            return;
        }

        try (Scanner doctorInput = new Scanner(doctorFile)) {

            if (doctorInput.hasNextLine()) {
                doctorInput.nextLine();
            }
            while (doctorInput.hasNextLine()) {
                String line = doctorInput.nextLine().trim();

                if (line.isEmpty()) {
                    continue;
                }

                try {
                    String[] data = line.split("\\s*-\\s*");

                    if (data.length < 7) {
                        System.out.println("تم تجاهل سطر غير مكتمل: " + line);
                        continue;
                    }

                    Doctor doctor = new Doctor(
                            data[0].trim(),
                            data[1].trim(),
                            data[2].trim(),
                            Double.parseDouble(data[3].trim()),
                            Integer.parseInt(data[4].trim()),
                            data[5].trim(),
                            Double.parseDouble(data[6].trim())
                    );

                    doctors.add(doctor);
                    people.add(doctor);

                } catch (NumberFormatException exception) {
                    System.out.println("تم تجاهل سطر يحتوي رقماً غير صالح: " + line);
                }
            }

        } catch (FileNotFoundException exception) {
            showAlert(Alert.AlertType.ERROR, "خطأ", "تعذر فتح ملف doctors.txt.");
        }
    }

    private void createNurses() {
        Nurse nurse1 = new Nurse("Ahmad", "999999999", "0599888888", 2500, 8, "Emergency", 12);

        Nurse nurse2 = new Nurse("Mona", "888888888", "0599777777", 2400, 7, "Children", 20);

        nurses.add(nurse1);
        nurses.add(nurse2);
        people.addAll(nurses);
    }

    private void saveAppointmentsToFile() {
        File outputFile = new File("src/datebase/restaurant/hospital/appointments.txt");

        try (PrintWriter writer = new PrintWriter(outputFile)) {

            writer.println("Doctor - Patient - Date - Time - Status");

            for (Appointment appointment : appointments) {
                writer.println(
                        appointment.getDoctor().getName()
                                + " - "
                                + appointment.getPatient().getName()
                                + " - "
                                + appointment.getDate()
                                + " - "
                                + appointment.getTime()
                                + " - "
                                + appointment.getStatus()
                );
            }

            showAlert(Alert.AlertType.INFORMATION, "نجاح الحفظ", "تم حفظ المواعيد في appointments.txt بنجاح.");

        } catch (FileNotFoundException exception) {
            showAlert(Alert.AlertType.ERROR, "خطأ", "تعذر الوصول إلى ملف appointments.txt.");
        }
    }

    private void setFontSize(
            double fontSize,
            javafx.scene.Node... nodes
    ) {
        for (javafx.scene.Node node : nodes) {

            if (node instanceof TextInputControl) {
                ((TextInputControl) node).setFont(
                        new Font(fontSize));

            } else if (node instanceof ComboBox) {
                node.setStyle("-fx-font-size: " + fontSize + "px;");

            } else if (node instanceof Labeled) {
                ((Labeled) node).setFont(new Font(fontSize));
            }
        }
    }

    private void showAlert(Alert.AlertType type, String title, String text
    ) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(text);
        alert.showAndWait();
    }
}
