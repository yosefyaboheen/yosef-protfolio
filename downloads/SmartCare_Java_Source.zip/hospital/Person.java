package datebase.restaurant.hospital;

public abstract class Person {
    private static int nextId = 0;
    private int id;
    private String name;
    private String nationalId;
    private String phone;

    public Person(String name, String nationalId, String phone) {
        this.id = ++nextId;
        this.name = name;
        this.nationalId = nationalId;
        this.phone = phone;
    }

    public static int getNextId() {
        return nextId;
    }


    public int getId() {
        return id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNationalId() {
        return nationalId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public abstract void displayInfo();
}
