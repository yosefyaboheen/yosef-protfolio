package datebase.restaurant.hospital;

public class Bed {

    private int bedNumber;
    private Room room;
    private Patient patient;
    private boolean occupied;


    public Bed(int bedNumber, Room room, Patient patient, boolean occupied) {

        this.bedNumber = bedNumber;
        this.room = room;
        this.patient = patient;
        this.occupied = occupied;
    }

    public Bed(int bedNumber, Room room) {

        this(bedNumber, room, null, false);
    }

    public int getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(int bedNumber) {
        this.bedNumber = bedNumber;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    public void displayInfo() {

        System.out.println("Bed Number: " + bedNumber);
        System.out.println("Room Number: " + room.getRoomNumber());

        if (patient != null) {
            System.out.println("Patient: " + patient.getName());
        } else {
            System.out.println("Patient: None");
        }

        System.out.println("Occupied: " + occupied);
    }
}
