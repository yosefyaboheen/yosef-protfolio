package datebase.restaurant.hospital;

public class Patient extends Person {
    private String bloodType;
    private String diagnosis;

    public Patient(String name, String nationalId, String phone, String bloodType, String diagnosis) {
        super(name, nationalId, phone);
        this.bloodType = bloodType;
        this.diagnosis = diagnosis;
    }

    public Patient(String name, String nationalId, String phone, String bloodType) {
        this(name, nationalId, phone, bloodType, "Unknown");
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    @Override
    public void displayInfo() {
        System.out.println("نوع الشخص: مريض");
        System.out.println("Patient ID: " + getId());
        System.out.println("Name: " + getName());
        System.out.println("National ID: " + getNationalId());
        System.out.println("Phone: " + getPhone());
        System.out.println("Blood Type: " + bloodType);
        System.out.println("Diagnosis: " + diagnosis);
    }
}
