package datebase.restaurant.hospital;

public class Nurse extends Employee {
    private String department;
    private int room;

    public Nurse(String name, String nationalId, String phone, double salary, int workingHours, String department, int room) {
        super(name, nationalId, phone, salary, workingHours);
        this.department = department;
        this.room = room;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    @Override
    public void displayInfo() {
        System.out.println("نوع الشخص: ممرض");
        System.out.println("Name: " + getName());
        System.out.println("Nurse ID: " + getId());
        System.out.println("National ID: " + getNationalId());
        System.out.println("Phone: " + getPhone());
        System.out.println("Salary: " + getSalary());
        System.out.println("Working Hours: " + getWorkingHours());
        System.out.println("Department: " + department);
        System.out.println("Room: " + room);
    }
}
